<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Krishana Associates</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FBFBFB">
 <?php include 'logo.php';?>
 <div class="main_first">
<div id='cssmenu' style="width:100%;   border-radius:1px">
<ul>
   <li class='active '><a href='index.html'><span>Home</span></a></li>
   <li><a href='aboutus.php'><span>Company Profile</span></a></li>
   <li class='has-sub '><a href='services.php'><span>Services</span></a>
      <ul>
         <li class='has-sub '><a href='services.php'><span>Labour Supply</span></a>
            
         <li class='has-sub '><a href='services.php'><span>Vehical Rental</span></a>
            <ul>
               <li><a href='services.php'><span>Vehical Rental in Govt. Sector</span></a></li>
               
            </ul>
         </li>
          <li class='has-sub '><a href='services.php'><span>Construction </span></a>
            <ul>
               <li><a href='services.php'><span>  Material</span></a></li>
                <li><a href='services.php'><span>  Equipment</span></a></li>
                 <li><a href='services.php'><span>  Equipment on Rent</span></a></li>
            </ul>
         </li>
          <li class='has-sub '><a href='services.php'><span>Work Tender</span></a>
            <ul>
               <li><a href='services.php'><span>IT Sector</span></a></li>
                <li><a href='services.php'><span> Electrical</span></a></li>
                 <li><a href='services.php'><span>Civil</span></a></li>
                  <li><a href='services.php'><span>Mechanical</span></a></li>
            </ul>
         </li>
      </ul>
   </li>
   <li><a href='#'><span>Equipment</span></a></li>
    
   <li><a href='#'><span>Contact Us</span></a></li>
</ul>
</div>  </div>
 <?php include 'home.php';?>
<?php include 'footer.php';?>
 

</body>
</html>
