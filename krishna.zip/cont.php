ccccccc<div style="margin-left:10%; margin-top:3px;width:80%;border:1px solid #CCCCCC;height:auto; margin-right:10%; color:#009900;">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Contact us :-</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="180"><div style="height:180px; margin-left:10px;  border:1px  double #CCCCCC; padding-left:20px; color:#333333" >
      <p><strong><u>Registered Office :</u></strong><br />
        Krishana  Associates<br />
        10-F,  Sidharipur, Surajkund,<br />
        Near&nbsp; Netaji Subhash Chowk,<br />
        Gorakhpur-273015&nbsp; (U.P.)<br />
        Phone :  0551-6453265 (Office)<br />
        Mobile : +91-9235122733</p>
    </div></td>
    <td><div style="height:180px; margin-left:10px; border:1px solid #CCCCCC; padding-left:20px;color:#333333 ">
      <p><strong><u>Branch Office :</u></strong><br />
        Krishana  Associates<br />
        G-86, Flat  No.3,&nbsp; Nashara Campus,<br />
        Sanjay  Gandhipuram,<br />
        Lucknow-226001  (U.P.)<br />
        Mobile :  +91-9336099911, 8799037745<br />
  <strong>Email : </strong><strong>krishana_associates@in.com</strong><strong> </strong></p>
    </div></td>
    <td><div style="height:180px; margin-left:10px; margin-right:10px; border:1px solid #CCCCCC; padding-left:20px; color:#333333" >
      <p><strong><u>Associates Office :</u></strong><br />
        Krishana  Associates<br />
        B-17, Balajipuram,  Rajkishore Nagar,<br />
        Behind Axis  Bank, Lingiyadiah,<br />
        Bilaspur-495006  (C.G.)<br />
        Phone :  07752-412376<br />
        Mobile :  +91-9584411666,<br />
  <strong> </strong></p>
    </div></td>
  </tr>
  <tr> <td align="center" ><a href="#" title="men power supply" style="color:#999999"> </a></td>
    <td align="center"><a href="#" title="Construction metarial and equipment" style="color:#999999"> </a></td>
    <td align="center"><a href="#" title="Vehical rental in govt. sector" style="color:#999999"> </a></td> 
  </tr>
</table>

 
</div>
<div style="margin-left:10%; margin-top:10px;width:80%;border:1px solid #CCCCCC;height:auto; margin-right:10%; color:#009900; text-decoration:none">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Services : </td>
    <td style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Reach us :</td>
    <td style="color:#000033; font-size:20px;padding-left:10px;color:#009900; ">Query : </td>
    </tr>
  <tr>
    <td height="182" rowspan="2">
    
    <?php include 'servicesmenu.php'; ?> </td>
    <td width="34%" rowspan="2">
    <div style="height:150px; border:1px solid #CCCCCC; padding-top:20px; padding-left:20px; font-size:17px; padding-right:15px; color:#333333" align="justify" >
     Contact us :  <br /><br />
      Mobile   : +91-9584411666 <br />
     Phone :  07752-412376 <br />
     info@krishanaassociates.com    </div></td>
    
  
    <td> <div style="width:auto; border:1px solid #CCCCCC; height:170px; padding-left:50px">
<form method="POST" name="contactform" action="contact-form-handler.php"> 
 
<label for='name'>Your Name:</label> <br>
<input type="text" name="name"><br />
 
 
<label for='email'>Email Address:</label> <br>
<input type="text" name="email"> <br>
 
 
<label for='message'>Enquiry</label> <br>
<textarea name="message"></textarea>
<input type="submit" value="Submit"><br>
</form>
</div>
<script language="JavaScript" src="scripts/gen_validatorv31.js" type="text/javascript"></script>
<script language="JavaScript">
// Code for validating the form
// Visit http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
// for details
var frmvalidator  = new Validator("contactform");
frmvalidator.addValidation("name","req","Please provide your name"); 
frmvalidator.addValidation("email","req","Please provide your email"); 
frmvalidator.addValidation("email","email","Please enter a valid email address"); 
</script>
 </td>
    </tr>
  
   
</table>

 
</div>