<div class="logo_div">
<table width="100%" border="0"  >
  <tr>
    <td width="230" rowspan="4"><img src="images/logo.bmp" width="230" height="100" /></td>
    <td width="123" rowspan="4">&nbsp;</td>
    <td width="184" rowspan="2">&nbsp;</td>
    <td width="145" rowspan="4">&nbsp;</td>
    <td width="268"><a href="http://webmail.krishanaassociates.com" target="_blank">Email</a> : krishana@krishanaassociates.com</td>
  </tr>
  <tr>
    <td>Mobile : +91-9584411666</td>
  </tr>
  <tr>
    <td width="184">&nbsp;</td>
    <td>Phone : 07752 - 412376</td>
  </tr>
  <tr>
    <td width="184">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>
