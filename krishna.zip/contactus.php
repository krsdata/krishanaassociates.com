-----------------<div class="contact_first">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Contact us :-</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="180"><div class="contact_second" style="78%">
      <p><strong><u>Branch Office  :</u></strong><br />
        Krishana  Associates<br />
        10-F,  Sidharipur, Surajkund,<br />
        Near&nbsp; Netaji Subhash Chowk,<br />
        Gorakhpur-273015&nbsp; (U.P.)<br />
        Phone :  0551-6453265 (Office)<br />
        Mobile : +91-9235122733</p>
    </div></td>
    <td><div class="contact_third">
      <p><strong><u>Branch Office :</u></strong><br />
        Krishana  Associates<br />
        G-86, Flat  No.3,&nbsp; Nashara Campus,<br />
        Sanjay  Gandhipuram,<br />
        Lucknow-226001  (U.P.)<br />
        Mobile :  +91-9336099911, 8799037745<br />
  <strong>Email : </strong><strong>krishana_associates@in.com</strong><strong> </strong></p>
    </div></td>
    <td><div style="height:180px; margin-left:10px; margin-right:10px; border:1px solid #CCCCCC; padding-left:20px; color:#333333" >
      <p><strong><u>Registered Office:</u></strong><br />
        Krishana  Associates<br />
        B-17, Balajipuram,  Rajkishore Nagar,<br />
        Behind Axis  Bank, Lingiyadiah,<br />
        Bilaspur-495006  (C.G.)<br />
        Mobile :  +91-9584411666,<br />
  <strong> </strong></p>
    </div></td>
  </tr>
  <tr> <td align="center" ><a href="#" title="men power supply" style="color:#999999"> </a></td>
    <td align="center"><a href="#" title="Construction metarial and equipment" style="color:#999999"> </a></td>
    <td align="center"><a href="#" title="Vehical rental in govt. sector" style="color:#999999"> </a></td> 
  </tr>
</table>

 
</div>
<div class="contact_fif">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Services : </td>
    <td style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Reach us :</td>
    <td style="color:#000033; font-size:20px;padding-left:10px;color:#009900; ">&nbsp;</td>
    <td width="20%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900; border-bottom:1px solid #CCCCCC">Query : </td>
  </tr>
  <tr>
    <td height="182" rowspan="5">
    
    <?php include 'servicesmenu.php'; ?> </td>
    <td width="34%" rowspan="5">
    <div class="contact_six">
     Contact us :  <br /><br />
      Mobile   : +91-9584411666 <br />
    
     info@krishanaassociates.com    </div></td>
    </tr> <form action="#" method="post">
  <tr>
    <td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name :</td>
    <td><input type="text" name="name"  /></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email Id :</td>
    <td><input type="text" name="email" /></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enquiry :</td>
    <td><input type="text" name="enquiry"   /></td>
  </tr>
  
  <tr>
    <td height="68">&nbsp;</td>
    <td><input type="submit" value="submit"  onclick="alert('Thank you ..!')"/></td>
  </tr> </form>
</table>

 
</div>