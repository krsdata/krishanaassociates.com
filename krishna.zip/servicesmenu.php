<div class="service_menu"> <ul>
    <li type="square" ><a href="services.php" style="text-decoration:none; color:#333333">LABOUR SUPPLY</a></li>
      <li type="square"> <a href="services.php"  style="text-decoration:none; color:#333333">VEHICLE RENTAL</a> </li>
      <li type="square"> <a href="services.php"  style="text-decoration:none; color:#333333">CONSTRUCTION MATERIAL</a></li>
      <li type="square"> <a href="services.php"  style="text-decoration:none; color:#333333">CONSTRUCTION EQUIPMENT</a> </li>
      <li type="square"> <a href="services.php"  style="text-decoration:none; color:#333333">WORK TENDER</a> </li>
    </ul>
    </div>

