<div class="footer_main">
     <table width="100%" border="0" bgcolor="#333333" >
  <tr>  
    <a href="#"><td width="80%"   style="color:#FFFFFF; padding-right:10px"> All Right Reserved &copy; Krishana Associates 2013</td></a>
    <td width="20%" align="center">Powered by : - <a href="http://www.infowayindia.in" style="color:#FFFFFF;" title="www.infowayindia.in"> Infoway </a></td>
  </tr>
</table>
</div>