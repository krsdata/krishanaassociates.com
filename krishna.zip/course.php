<div class="course_main">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Inovation</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Student Library</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Opportunities</td>
  </tr>
  <tr>
    <td height="182"><div class="course_td"><img src="images/page1-img1.jpg" width="100%" height="150" /></div></td>
    <td><div class="course_td"><img src="images/page1-img2.jpg" width="100%" height="150" /></div></td>
    <td><div class="course_td"> <img src="images/page1-img3.jpg" width="100%" height="150" /></div></td>
  </tr>
  <tr>
    
  </tr>
</table>

 
</div>
<div class="course_second">

<table width="100%" height="247" border="0" bgcolor="#FFFFFF">
  <tr style="font-size:18px;">
    <td width="33%" height="39" align="center"><strong style="color:#009900">Commerce stream</strong></td>
    <td width="33%" align="center"><strong style="color:#009900">Management</strong></td>
    <td colspan="2" align="center"><strong style="color:#009900">Science Stream</strong></td>
  </tr>
  <tr>
    <td height="202" align="justify" >
    <div class="course_third">
        <ul><li type="square"><a href="#"> B.com Plan  </a></li>
      <li type="square"><a href="#">B.com (Computer Science) </a></li>
      <li type="square"><a href="#">B.com(Tax procedure)</a></li>
       <li type="square"><a href="#">B.com (Foreign Trade)</a></li>
        </ul> 
        <br>
       
    </div> </td>
    <td> <div class="course_fourth">
      <ul>
        <li type="square"><a href="#"> BBA</a></li>
        <li type="square"><a href="#">MBA(Marketing)</a><a href="#"></a></li>
        <li type="square"><a href="#">MBA</a><a href="#"></a>(Finance)</li>
        <li type="square"><a href="#">MBA</a><a href="#"></a>(HR)</li>
      </ul>
     </div></td>
    <td colspan="2">
    <div class="course_fifth">
    
    <ul>
      <li type="square"><a href="#" onclick="alert('For more details about Admission please contact : +91- or Visit our Office');">Bsc</a><sup><span style="color:#FF0000; text-decoration:blink"></span></sup></li>
      <li type="square"><a href="#" >Bsc(CS)</a></li>
      <li type="square"><a href="#" >Bsc(Hons)</a></li>
       <li type="square"><a href="#" >MCA</a></li>
        <li type="square"><a href="#" >BSc. 
(Biotechnology)</a> </li>
<li type="square"><a href="#" onclick="alert('For more details about Scholarship please contact : +91- or Visit our Office');">BSc. 
(micro-biology)</a> </li>
<li type="square"><a href="#" onclick="alert('For more details about Scholarship please contact : +91- or Visit our Office');">MSc. 
</a> </li>
     </ul>
    </div></td>
    </tr>
    
</table>


</div>