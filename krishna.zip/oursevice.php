<div class="our_service_main">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="61" style=" font-size:20px; padding-left:10px; color:#009900">OUR SERVICES : </td>
    <td width="36%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="31%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="158"><div class="ourservice_td"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/Labour-Supply.jpg" width="100%" height="170" title="men power supply" /></a></div></td>
    <td><div class="ourservice_td"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/construction.jpg" width="100%" height="170" title="Construction metarial and equipment"/></a></div></td>
    <td><div class="ourservice_td_second"> <a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/vehical.jpg" title="Vehical rental in govt. sector" width="100%" height="170" /></a></div></td>
  </tr>
<tr>   <td height="160"> <div class="ourservice_third"> <p><a href="#" title="men power supply" style="color:#999999; ">LABOUR SUPPLY</a></p>
    
    <ul><li type="square"> Mason
    Gang    
    <li type="square"> Carpenter    
    <li type="square"> Fabricator  </ul> 
</div> </td> 
    <td >
	 <div class="ourservice_fourth">  
	<p><a href="#" title="Construction metarial and equipment" style="color:#999999">CONSTRUCTION </a></p> 
	<ul>
	  <li type="square">Construction Equipment On Rent Basis      
	  
	  <li type="square"> Building Materials       
	  <li>General Order Supply
	    </ul>
		</p> </div></td>
    <td > <div class="ourservice_fifth">
	
	 <p><a href="#" title="work tender in IT.civil, maechanical, electrical" style="color:#999999">WORK TENDER</a></p>
       <ul>
        <li type="square">IT SECTOR</li>
        <li type="square"> CSEB, UPPCL</li>
        <li type="square"> Real Estate</li>
        <li type="square"> Power Plant</li>
        <li type="square"> Railway &amp; BSNL</li>
      </ul>
       
      </div></td> 
  </tr>
</table>

 
</div>
<div class="ourservice_sixth">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Vehical Rent </td>
    <td style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp;</td>
    <td width="31%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Services deal by region </td>
    </tr>
  <tr>
    <td height="182" rowspan="2"> <div class="ourservice_seventh" > <a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/vehical.jpg" title="Vehical rental in govt. sector" width="100%" height="170" /></a></div></td>
    <td width="36%" rowspan="2">
    <div class="ourservice_eighth">
     <ul style="color:#009900">
       <li type="square">VEHICLE RENTAL IN GOVT SECTOR</li>
       <li type="square"> INDIGO</li>
       <li type="square"> SCORPIO</li>
       <li type="square"> BOLERO.</li>
       </ul>
    </div></td>
     
  
    <td rowspan="2">  
  <div class="ourservice_ninth">
  
  <a href="contact.php" style="color:#666666"><ul> <li type="square">Registered Office : <br />        <u><strong>Vehicle Rental & Tender </strong></u></li>    <li type="square">Branch Office : <br /> <u> <strong>IT Sector Tender </strong></u></li>   <li type="square">Associate Office : <br />   <u> <strong>Construction & All Govt. Tender </strong> </u></li> </ul></a>
   
  </div>
</td>
    </tr>
  
  
</table>

 
</div>