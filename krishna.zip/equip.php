<div class="equip_main" >
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">&nbsp;</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
 <tr>
    <td height="158"><div class="ourservice_td"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/Labour-Supply.jpg" width="100%" height="170" title="men power supply" /></a></div></td>
    <td><div class="ourservice_td"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/construction.jpg" width="100%" height="170" title="Construction metarial and equipment"/></a></div></td>
    <td><div class="ourservice_td_second"> <a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/vehical.jpg" title="Vehical rental in govt. sector" width="100%" height="170" /></a></div></td>
  </tr>
  <tr> <td align="center" ><a href="#" title="men power supply" style="color:#999999">Men Power Supply</a></td>
    <td align="center"><a href="#" title="Construction metarial and equipment" style="color:#999999">Construction Material</a></td>
    <td align="center"><a href="#" title="work tender in IT.civil, maechanical, electrical" style="color:#999999">Work Tender (ITsectot,civil,mechanical etc)</a></td> 
  </tr>
</table>

 
</div>
<div class="equip_second">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Services</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Equipment we offer :</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="182">
    
    <?php include 'servicesmenu.php'; ?>
    <div class="below_sevice"></div>
    <div class="below_sevice"></div>
    <div class="below_sevice_second"></div>
    </td>
    <td colspan="2">
    <div class="equip_third">
      <p>We are able to provide you  all the following equipment with quality service and competitive price from our  ready stock:-</p>
      <ul type="disc">
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">WHEEL LOADER       (SHOWEL) CAT 936, 950,966,980 &amp; 988</span></li>
        <li><span mso-bidi-font-family:=""       "="">&nbsp;&nbsp;SHOVEL 936, SHOVEL 950, SHOVEL 966,       SHOVEL 980, SHOVEL 988</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">JCB       3CX&nbsp; SITEMASTER</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">JCB WITH       BREAKER</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">TELEHANDLER       13 mtr, 14 mtr &amp; 17 mtr. &nbsp;</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">MANLIFT 15       MTR TO 27 MTR. (DIESEL &amp; ELECTRIC)</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">SCISSOR LIFT       4 MTR TO 20 MTR (DIESEL &amp; ELECTRIC)</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">TRAILER 40-       60 (Flat top) &amp; LOWBED TRAILER</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">MOBILE       CRANES 20 to 400 TON CAPACITY</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">CRAWLER       CRANE 25 TON TO 300 TON</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">CRANE TRUCK       (Hiab) 1 TON TO 7 TON</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">AIR       COMPRESSOR 150 CFM to 900 CFM</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">GENERATORS 5       Kva to 1500 Kva</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">FORKLIFT 2.5       TON to 25 TON</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">BULLDOZER       D6, D7, D8 &amp; D9</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">EXCAVATOR       20Ton&nbsp; to&nbsp; 800Ton&nbsp;</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">EXCAVATOR       WITH BREAKER</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">ROLLER       COMPACTOR 10-25 TON (MODEL-2011)</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">PNUEMATIC       TYRE ROLLER (PTR)</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">BOBCAT</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">PLATE       COMPACTOR</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">ASPHALT       CUTTER</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">GRADER CAT       12 G &amp; 14 G</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">TIPPER 20M3&nbsp;&amp; 40M3</span></li>
        <li>&nbsp;&nbsp;<span mso-bidi-font-family:="" "="">WELDING       MACHINE (DIESEL &amp; ELECTRIC</span>)</li>
        <li>&nbsp;&nbsp; PAY LOADER (SHOVEL)</li>
      </ul>
    </div></td>
    </tr>
</table>

 
</div>