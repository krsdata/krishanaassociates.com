<div class="home_main">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
<tr><marquee scrolldelay="180" direction="left"> Also Available  ICICI Bank Connector Referral Program in india (All Types of Loan) </marquee></tr>
  <tr>
    <td width="33%" height="10" style=" font-size:20px; padding-left:10px; color:#009900">&nbsp;</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="158"><div class="home_td"><a href="#" onclick="alert('For more details please call : +91- 8602586590');"><img src="images/Labour-Supply.jpg" width="100%" height="170" title="men power supply" /></a></div></td>
    <td><div class="home_td"><a href="#" onclick="alert('For more details please call : +91- 8602586590');"><img src="images/construction.jpg" width="100%" height="170" title="Construction metarial and equipment"/></a></div></td>
    <td><div class="home_td_second"> <a href="#" onclick="alert('For more details please call : +91- 8602586590');"><img src="images/vehical.jpg" title="Vehical rental in govt. sector" width="100%" height="170" /></a></div></td>
  </tr>
  <tr> <td align="center" ><a href="#" title="men power supply" style="color:#999999">Men Power Supply</a></td>
    <td align="center"><a href="#" title="Construction metarial and equipment" style="color:#999999">Construction Equipment</a></td>
    <td align="center"><a href="#" title="Vehical rental in govt. sector" style="color:#999999">Vehical Rental in Govt Sector</a></td> 
  </tr>
</table>

 
</div>
<div class="home_third">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px;">Services</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;">About us :</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="182">
    
    <?php include 'servicesmenu.php'; ?></td>
    <td colspan="2">
    <div class="home_fourth">
      <span style="font-size:18px"><strong>Krishana Associates </strong></span>is a sole proprietorship company and was established  with an aim to provide simple and comprehensive solution in the field of General order Supplier, Labour supply, Condtruction material and equipment Rent Basis Of Vehicle & Work Contract experience in this field has mastered us in delivering the complete solution. we always been able to serve our esteemed clients with the simple solution, which suits the standard, and need of our valuable clients.</div></td>
    </tr>
</table>

 
</div>