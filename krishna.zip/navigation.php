<div class="navigation_main">
<div id='cssmenu' class="menu_div">
<ul>
   <li class='active '><a href='index.php'><span>Home</span></a></li>
   <li><a href='about.php'><span>Company Profile</span></a></li>
   <li class='has-sub '><a href='services.php'><span>Services</span></a>
      <ul>
         <li class='has-sub '><a href='services.php'><span>Labour Supply</span></a>
            
         <li class='has-sub '><a href='services.php'><span>Vehical Rental</span></a>
            
         </li>
          <li class='has-sub '><a href='services.php'><span>Construction </span></a>
            
         </li>
          <li class='has-sub '><a href='services.php'><span>Work Tender</span></a>
             
         </li>
      </ul>
   </li>
   <li><a href='equipment.php'><span>Equipment</span></a></li>
    
   <li><a href='contact.php'><span>Contact Us</span></a></li>
</ul>
</div>  </div> 