<div class="about_first">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">&nbsp;</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="158"><div class="about_second"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/Labour-Supply.jpg" width="100%" height="170" title="men power supply" /></a></div></td>
    <td><div class="about_second"><a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/building.jpg" width="100%" height="170" title="Construction metarial and equipment"/></a></div></td>
    <td><div class="about_third"> <a href="#" onclick="alert('For more details please call : +91-9584411666');"><img src="images/work-tenders.jpg" title="Vehical rental in govt. sector" width="100%" height="170" /></a></div></td>
  </tr>
  <tr> <td align="center" ><a href="#" title="men power supply" style="color:#333333">Men Power Supply</a></td>
    <td align="center"><a href="#" title="Construction metarial and equipment" style="color:#333333">Construction Material</a></td>
    <td align="center"><a href="#" title="work tender in IT.civil, maechanical, electrical" style="color:#333333">Work Tender : IT Sector, Civil, Mechanical Etc.</a></td> 
  </tr>
</table>

 
</div>
<div class="about_fourth">
  <table width="100%" border="0" bgcolor="#FFFFFF" style="color:#009933">
  <tr>
    <td width="33%" height="42" style=" font-size:20px; padding-left:10px; color:#009900">Services</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">Company Profile :</td>
    <td width="33%" style="color:#000033; font-size:20px;padding-left:10px;color:#009900">&nbsp; </td>
  </tr>
  <tr>
    <td height="182">
    
    <?php include 'servicesmenu.php'; ?>
    <div class="below_sevice"></div>
    </td> 
    <td colspan="2">
    <div class="about_fifth">
      <p><span style="font-size:18px"><strong>Krishana Associates </strong></span>is a sole proprietorship company and  with an aim to provide simple and comprehensive solution in the field of General order Supplier, Rent Basis of Vehicle & Work Contract experience in this field has mastered us in delivering the complete solution. we always been able to serve our esteemed clients with the simple solution, which suits the standard, and need of our valuable clients. <a href="#"> </a>      </p>
      <p>We  have always been trusted when the nature of job was highly classified and the  time really matters. Our success, in large part, has been based on business  philosophy that values quality products, fiscal independence and long-term  customer relationship </p>
      We stay up to date on technology as it becomes available but we never suggest new technology just because it is new. Our job is to select the best techniques to solve our client’s problems and help them to take advantage of their opportunities. Rather than try to make client fit our solution, we make sure that our solution fits clients
    .</div></td>
    </tr>
</table>

 
</div>